from .settings import *
from .button import *
import pygame
import numpy
pygame.init()
pygame.font.init()